#!/bin/bash
set -e

printf '[client]\nskip-ssl\n' > /home/frappe/.my.cnf

if [ -n "${NVM_DIR:-}" ] && [ -n "${NODE_VERSION_DEVELOP:-}" ]; then
    export PATH="${NVM_DIR}/versions/node/v${NODE_VERSION_DEVELOP}/bin:${PATH}"
fi

# Phase 1: Create bench if not yet initialized
if [ ! -d "/home/frappe/frappe-bench/apps/frappe" ]; then
    echo "Creating new bench for local lms-frappe checkout..."
    bench init --skip-redis-config-generation --frappe-branch develop frappe-bench
fi

cd /home/frappe/frappe-bench

# Ensure bench points at Docker Compose containers and skips bundled redis/watch
bench set-mariadb-host mariadb
bench set-redis-cache-host redis://redis:6379
bench set-redis-queue-host redis://redis:6379
bench set-redis-socketio-host redis://redis:6379
sed -i '/redis/d' ./Procfile
sed -i '/watch/d' ./Procfile
sed -i 's/^web: bench serve.*/web: bench serve --host 0.0.0.0 --port 8000/' ./Procfile
grep -q '^lms-ui:' ./Procfile || echo 'lms-ui: cd apps/lms/frontend && yarn dev' >> ./Procfile

# Phase 2: Ensure payments app, local lms symlink, sibling frappe symlink, and clean apps.txt
if [ ! -d "/home/frappe/frappe-bench/apps/payments" ]; then
    bench get-app payments
fi

ln -sfn /home/frappe/local-apps/lms /home/frappe/frappe-bench/apps/lms
ln -sfn /home/frappe/frappe-bench/apps/lms/lms/public /home/frappe/frappe-bench/sites/assets/lms
sudo chown frappe:frappe /home/frappe/local-apps 2>/dev/null || true
ln -sfn /home/frappe/frappe-bench/apps/frappe /home/frappe/local-apps/frappe 2>/dev/null || true
ln -sfn /home/frappe/frappe-bench/sites /home/frappe/sites

# Write clean newline-separated apps.txt (fixes paymentslms concatenation)
printf 'frappe\npayments\nlms\n' > sites/apps.txt

if ! ./env/bin/python -c "import lms" 2>/dev/null; then
    bench setup requirements --python
    if ! ./env/bin/python -c "import lms" 2>/dev/null; then
        if command -v uv >/dev/null 2>&1; then
            uv pip install --python ./env/bin/python -e apps/lms
        else
            ./env/bin/pip install -e apps/lms
        fi
    fi
fi

if [ ! -d "apps/lms/frontend/node_modules" ]; then
    (cd apps/lms/frontend && yarn install --check-files)
fi
mkdir -p apps/lms/frontend/node_modules/@framework
ln -sfn /home/frappe/frappe-bench/apps/frappe/ui apps/lms/frontend/node_modules/@framework/ui

# Phase 3: Reconnect to existing MariaDB database (or create site if brand new)
if [ ! -f "/home/frappe/frappe-bench/sites/.lms_initialized" ]; then
    EXISTING_DB=$(mysql -hmariadb -uroot -p123 -N -e "SHOW DATABASES LIKE '\_%';" 2>/dev/null | head -n 1 || true)
    if [ -n "$EXISTING_DB" ]; then
        echo "Reconnecting lms.localhost to existing database $EXISTING_DB..."
        mysql -hmariadb -uroot -p123 -e "CREATE USER IF NOT EXISTS '$EXISTING_DB'@'%' IDENTIFIED BY '123'; ALTER USER '$EXISTING_DB'@'%' IDENTIFIED BY '123'; GRANT ALL PRIVILEGES ON \`$EXISTING_DB\`.* TO '$EXISTING_DB'@'%'; FLUSH PRIVILEGES;"
        mkdir -p /home/frappe/frappe-bench/sites/lms.localhost/private/files /home/frappe/frappe-bench/sites/lms.localhost/public/files /home/frappe/frappe-bench/sites/lms.localhost/locks /home/frappe/frappe-bench/sites/lms.localhost/logs
        cat <<EOF > /home/frappe/frappe-bench/sites/lms.localhost/site_config.json
{
 "db_name": "$EXISTING_DB",
 "db_password": "123",
 "db_type": "mariadb",
 "developer_mode": 1,
 "ignore_csrf": 1
}
EOF
    elif [ ! -f "/home/frappe/frappe-bench/sites/lms.localhost/site_config.json" ]; then
        bench new-site lms.localhost \
          --force \
          --mariadb-root-password 123 \
          --admin-password admin \
          --mariadb-user-host-login-scope='%'

        bench --site lms.localhost install-app payments
        bench --site lms.localhost install-app lms
    fi
    bench --site lms.localhost clear-cache
    bench use lms.localhost
    touch /home/frappe/frappe-bench/sites/.lms_initialized
fi

exec bench start
